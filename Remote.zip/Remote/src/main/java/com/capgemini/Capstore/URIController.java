package com.capgemini.Capstore;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.Product;



@Controller
public class URIController {
	
	
	

	@PersistenceContext
	EntityManager em;


	@RequestMapping("/")
	public  String home(ModelMap map) {
		
		
		
		Query query=em.createQuery("select p.prodCategory from Product p");
		List<String> list=query.getResultList();
		//System.out.println(list);
		map.addAttribute("categories",list);
		int noOfCategory=list.size();
		for(String Prodcategory:list) {
			
			query=em.createQuery("select p from Product p where p.prodCategory=:cat").setParameter("cat",Prodcategory);
			List<Product> productList=query.getResultList();
		//	for(int i=0;i<productList.size();i++)
		//	System.out.println(productList.get(i).getName());
			map.addAttribute(Prodcategory,productList);
		}
		
		
		 return "/views/index.jsp";
		
		
		
	}
	/*
	@RequestMapping("/index")
	public  String index() {
		
		return "/views/index.jsp";
		
		
	}

	@RequestMapping("/getLogin")
	public  String login() {
		
		return "/views/login.jsp";
		
		
	}
	
	@RequestMapping("/registerAsCustomer")
	public  String registerCustomer() {
		
		return "/views/registerCustomer.jsp";
		
		
	}
	
	
	@RequestMapping("/getContact")
	public  String contact() {
		
		return "/views/contact.jsp";
		
		
	}
	
	
	
	@RequestMapping(value="/getProduct/{productId}")
	public ModelAndView getProductPage(@PathVariable int productId ) {
		System.out.println("consoler"+productId);
		
		RestTemplate restTemplate = new RestTemplate();
		Product displayProduct = restTemplate.getForObject("http://localhost:8099/product.json",Product.class);
		return new ModelAndView("/views/product.jsp","product",displayProduct);
	}
	
	@RequestMapping(value="/getCheckout")
	public String getCheckoutPage() {
		
		return "/views/checkout.jsp";
	}
	
*/	}
